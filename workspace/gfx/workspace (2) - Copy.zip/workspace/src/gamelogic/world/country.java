package gamelogic.world;

import gamelogic.Event;
import gamelogic.Main;
import gamelogic.audio.SoundManager;

import java.util.ArrayList;
import java.util.List;

public class country {
    private String name;
    private double govtMoney;
    private int population;
    private double spending;
    private double defenseSpending;
    private double RGDP; //in dollars
    private double growthRate; //in percentage
    private double taxRate = 10; //in percentage
    private double extraSpending = 0; //in dollars
    private double interestRate;
    public List<Double> historicalInterestRates = new ArrayList<>();
    public List<Double> historicalTaxRates = new ArrayList<>();
    public List<Double> historicalSpending = new ArrayList<>();//in percentage
    private events event;
    private boolean inWar = false;
    public List<Event> countryNews;
    public int difficulty = 0;
    private int time = 0;
    public boolean bankrupted;
    private SoundManager sm = new SoundManager();

    public country(String name, int population, double GDP, double baseGrowthRate, double interestRate) {
        this.name = name;
        RGDP = GDP;
        this.population = population;
        growthRate = baseGrowthRate;
        this.interestRate = interestRate;
        sm.loadClip("war", "music/warmarch.wav");
        sm.loadClip("notonestepback", "music/dietotenerwachen.wav");
        sm.loadClip("badomen", "music/badomen.wav");
        event = new events();
        event.resetEvents();
        countryNews = new ArrayList<>();


    }

    public List<Event> getCountryNews() { return countryNews; }

    public void setTime(int time) {
        this.time = time;
    }

    public double getIR(){ return interestRate; }

    public int getTime(){ return time; }

    public boolean isInWar() { return inWar; }

    public double getGDP() {
        return RGDP;
    }

    public void growEconomy() {
        RGDP += RGDP * growthRate;
    }

    public int getPop() {
        return population;
    }

    public double getInterestRate() { return interestRate; }


    public void collectTaxes() {
        govtMoney += RGDP * (taxRate / 100);
    }

    public void splitSpending() {
        if (govtMoney > 0) {
            spending = govtMoney * 0.7;
            govtMoney -= govtMoney * 0.7;
            defenseSpending = govtMoney * 0.2;
            govtMoney -= govtMoney * 0.2;
            govtMoney -= extraSpending;

        } else if (govtMoney > -1000000000000.0) {

        } else {
            defenseSpending = 0;
            extraSpending = 0;
        }

    }

    public void changeSpending(double amount) {
        historicalSpending.add(extraSpending);
        extraSpending += amount;
    }

    public void changeTaxes(double amount) {
        historicalTaxRates.add(taxRate);
        taxRate += amount;
    }

    public void changeIR(double amount) {

        historicalInterestRates.add(interestRate);
        interestRate += amount;
        if (interestRate < 0) {
            interestRate = 0;
        }

    }
    public void initialNews() {
        countryNews.add(new Event("welcome"));
    }
    public void hardNews() {
        countryNews.add(new Event("aboutWar"));
        countryNews.add(new Event("welcome"));
    }

    //functions when the player sleeps
    public void timeLapse() {
        time += 1;
        collectTaxes();
        splitSpending();
        countryNews.clear();
        if (difficulty == 1 && time == 9) {
            startWar();
        }
        while(countryNews.size() < 3) {
            countryNews.add(new Event(eventGetter()));
        }



    }

    public void startWar() {
        countryNews.add(new Event("warDeclare"));
        inWar = true;
    }

    //will return a random event
    public String eventGetter() {

        String currentEvent = event.getRandomEvent();

        if (inWar && countryNews.size() <= 2) {
            currentEvent = event.getRandomWarEvent();
        }

        double randomChangeRate = (double) (Math.random() * 3);
        if (currentEvent.equals("increaseSpending")) {
            changeSpending((randomChangeRate * spending) / 100);

        } else if (currentEvent.equals("decreaseSpending")) {
            changeSpending(-(randomChangeRate * spending) / 100);

        } else if (currentEvent.equals("increaseTax")) {
            changeTaxes(randomChangeRate);

        } else if (currentEvent.equals("decreaseTax")) {
            changeTaxes(-randomChangeRate);

        } else if (currentEvent.equals("increaseIR")) {
            changeIR(randomChangeRate);

        } else if (currentEvent.equals("decreaseIR")) {
            changeIR(-randomChangeRate);

        } else if (currentEvent.equals("bankrupt")) {
            bankrupted = true;
            Main.bankrupted = true;

        } else if (currentEvent.equals("warDeclare")) {
            inWar = true;

        } else if (currentEvent.equals("invasion")) {
            inWar = true;

        } else if (currentEvent.equals("bombing")) {
            population -= (int) randomChangeRate * 100;

        } else if (currentEvent.equals("battle")) {

        } else if (currentEvent.equals("weaponFirm")) {

        } else if (currentEvent.equals("forward")) {

        } else if (currentEvent.equals("backward")) {

        } else if (currentEvent.equals("surrender")) {
            inWar = false;

        } else if (currentEvent.equals("victory")) {
            inWar = false;

        } else if (currentEvent.equals("healthyBurger")) {

        } else if (currentEvent.equals("boycott")) {
            growthRate -= randomChangeRate;

        } else if (currentEvent.equals("forestBurn")) {
            Main.extraProductionCost += 20;

        } else if (currentEvent.equals("iceMelt")) {
            Main.extraProductionCost += 10;

        } else if (currentEvent.equals("goldRush")) {
            Main.goldCost += Main.goldCost * 2 * (randomChangeRate/100);

        } else if (currentEvent.equals("construction")) {

        }

        return currentEvent;

    }


    public String getName() {
        return name;
    }

    public double getTax() {
        return taxRate;
    }

    public void setDifficulty(int selectedDifficulty) {
        difficulty = selectedDifficulty;
    }

    public double getSpending() {
        return spending;
    }
}
