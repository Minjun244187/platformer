package gamelogic.world;

public class Product {
    private String name;
    private String type;
    private double cost;
    private double productionCost;
    private int demand;

    public Product (String name, String type, double cost, int demand) {
        this.name = name;
        this.type = type;
        this.cost = cost;
        this.demand = demand;
    }

    public void setCost(double amount) {
        cost = amount;
        System.out.println("Set cost of " + name + " to $" + cost);
    }

    public void setProductionCost(double amount) {
        productionCost = amount;
    }

    public void changeProductionCost(double amount) {
        productionCost += amount;
    }

    public String getType() { return type; }

    public double getCost() { return cost; }

    public int getDemand() { return demand; }

    public void changeDemand(int amount) {
        demand += amount;
    }

    public double getProductionCost() {
        return productionCost;
    }
}
