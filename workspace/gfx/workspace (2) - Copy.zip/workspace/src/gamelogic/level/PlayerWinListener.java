package gamelogic.level;

public interface PlayerWinListener {
	public void onPlayerWin();
}
