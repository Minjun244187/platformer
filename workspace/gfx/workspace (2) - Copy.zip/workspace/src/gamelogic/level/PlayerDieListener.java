package gamelogic.level;

public interface PlayerDieListener {
	public void onPlayerDeath();
}
