package gamelogic;

public interface ScreenTransitionListener {
	public void onTransitionActivationFinished();
	
	public void onTransitionFinished();
}
